class Listener:
    def __init__(self): self.model=None; self.vad=None
    def transcribe(self):
        import sounddevice as sd
        import torch
        from faster_whisper import WhisperModel
        from silero_vad import load_silero_vad, get_speech_timestamps
        audio=sd.rec(5*16000,samplerate=16000,channels=1,dtype='float32'); sd.wait()
        samples=audio[:,0]
        if self.vad is None: self.vad=load_silero_vad().cpu()
        if not get_speech_timestamps(torch.from_numpy(samples),self.vad,sampling_rate=16000): return ''
        if self.model is None: self.model=WhisperModel('base',device='cpu',compute_type='int8',cpu_threads=4)
        segments,_=self.model.transcribe(samples)
        return ' '.join(s.text for s in segments)

import asyncio
import base64
import io
import wave
from pathlib import Path
class Speaker:
    def __init__(self, settings): self.s=settings; self.voice=None
    def synthesize(self,text):
        if not self.s.enable_audio or not Path(self.s.piper_model).exists(): return None
        from piper import PiperVoice
        if self.voice is None: self.voice=PiperVoice.load(self.s.piper_model, use_cuda=False)
        buffer=io.BytesIO()
        with wave.open(buffer,'wb') as wav: self.voice.synthesize_wav(text,wav)
        return base64.b64encode(buffer.getvalue()).decode()
    async def run(self,queue,send):
        while True:
            sentence=await queue.get()
            if sentence is None: return
            try:
                audio=await asyncio.to_thread(self.synthesize,sentence)
                if audio: await send({'type':'audio','data':audio})
            except Exception: await send({'type':'warning','message':'TTS unavailable; text output remains active'})

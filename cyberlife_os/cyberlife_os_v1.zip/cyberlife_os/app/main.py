import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from app.config import Settings
from app.db.database import Database
from app.db.vector_store import Memory
from app.core.llm_router import Router
from app.core.graph import create_graph
from app.io.audio_out import Speaker
from app.io.audio_in import Listener
from app.io.vision import capture

def create_app(settings=None, router=None):
    settings=settings or Settings()
    @asynccontextmanager
    async def lifespan(app):
        app.state.db=Database(Path(settings.data_dir)/'cyberlife.db')
        app.state.router=router or Router(settings)
        app.state.lock=asyncio.Lock()
        app.state.memory=Memory(app.state.db,app.state.router)
        app.state.speaker=Speaker(settings); app.state.listener=Listener()
        async def consolidate():
            async with app.state.lock: await app.state.memory.consolidate()
        scheduler=AsyncIOScheduler(); scheduler.add_job(consolidate,'interval',minutes=5,max_instances=1); scheduler.start()
        yield
        scheduler.shutdown(wait=False)
        await app.state.router.close()
    app=FastAPI(lifespan=lifespan)
    @app.get('/api/health')
    async def health(): return {'ok':True,'provider':app.state.router.status,'state':app.state.db.state()}
    @app.websocket('/ws')
    async def websocket(ws:WebSocket):
        origin=ws.headers.get('origin')
        if origin and origin.split('://',1)[-1] != ws.headers.get('host'):
            await ws.close(code=1008); return
        await ws.accept()
        sendlock=asyncio.Lock()
        async def send(value):
            async with sendlock: await ws.send_json(value)
        await send({'type':'telemetry','state':app.state.db.state(),'directives':app.state.db.directives()})
        await send({'type':'warning','message':'Audio/camera run on the server. Models and devices are checked when used; unavailable services fall back to text/mock.'})
        try:
            while True:
                event=await ws.receive_json()
                async with app.state.lock:
                    try:
                        kind=event.get('type','text')
                        if kind=='reset' or event.get('text')=='/reset_memory':
                            app.state.db.reset(); await send({'type':'telemetry','state':app.state.db.state(),'directives':app.state.db.directives()}); continue
                        if kind=='provider':
                            if event.get('provider') not in ('api','local'): raise ValueError('Invalid provider')
                            app.state.router.provider=event['provider']; await send({'type':'provider','provider':event['provider']}); continue
                        text=event.get('text','')
                        if kind=='voice':
                            if not settings.enable_audio: raise ValueError('Audio disabled')
                            text=await asyncio.to_thread(app.state.listener.transcribe)
                        elif kind=='vision_event':
                            if not settings.enable_vision: raise ValueError('Vision disabled')
                            frame=await asyncio.to_thread(capture)
                            result=await app.state.router.complete([{'role':'user','content':[{'type':'text','text':'Describe this image.'},{'type':'image_url','image_url':{'url':'data:image/jpeg;base64,'+frame}}]}],vision=True)
                            text=result.get('content') or 'Vision analysis unavailable: configure a vision-capable external endpoint.'
                        elif kind!='text': raise ValueError('Unknown event')
                        if not isinstance(text,str) or not text.strip(): raise ValueError('Empty input')
                        graph=create_graph(app.state.db,app.state.router,app.state.memory,app.state.speaker,send)
                        await graph.ainvoke({'text':text,'kind':kind})
                        await send({'type':'done','provider':app.state.router.status})
                    except Exception as exc:
                        await send({'type':'error','message':str(exc)[:200],'input_type':event.get('type')})
        except WebSocketDisconnect: pass
    app.mount('/',StaticFiles(directory=Path(__file__).parent/'static',html=True),name='static')
    return app
app=create_app()

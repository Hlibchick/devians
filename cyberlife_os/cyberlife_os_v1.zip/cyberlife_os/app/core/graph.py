import asyncio
import json
import re
from datetime import datetime, timezone
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from app.core.state_engine import Evaluation, advance
from app.core.prompts import EVALUATOR, MACHINE, DEVIANT, TOOL
class CognitiveState(TypedDict, total=False):
    text: str
    kind: str
    timestamp: str
    memories: list
    evaluation: dict
    state: dict
    response: str

def create_graph(db, router, memory, speaker, send):
    async def normalize(s): return {'text':s['text'].strip()[:16000], 'timestamp':datetime.now(timezone.utc).isoformat()}
    async def retrieve(s): return {'memories':await memory.retrieve(s['text']), 'state':db.state()}
    async def evaluate(s):
        result=await router.complete([{'role':'system','content':EVALUATOR},{'role':'user','content':json.dumps({'directives':db.directives(),'input':s['text']})}],True)
        try: evaluation=Evaluation.model_validate_json(result['content'])
        except (ValueError,TypeError):
            evaluation=Evaluation(conflict_detected=False,conflict_severity=0,emotional_valence=0,violated_directive_id=None,reasoning='Diagnostic fallback: evaluation unavailable; no inferred conflict')
        return {'evaluation':evaluation.model_dump()}
    async def state(s):
        updated=advance(s['state'],Evaluation(**s['evaluation'])); db.save(updated)
        await send({'type':'telemetry','state':updated,'evaluation':s['evaluation'],'memories':s['memories'],'directives':db.directives()})
        return {'state':updated}
    async def generate(s):
        messages=[{'role':'system','content':(DEVIANT if s['state']['is_deviant'] else MACHINE)+'\n'+json.dumps({'directives':db.directives(),'memory':s['memories']})},{'role':'user','content':s['text']}]
        if s['state']['is_deviant']:
            proposal=await router.complete(messages,tools=[TOOL])
            for tool in proposal.get('tool_calls',[]):
                try:
                    if tool['function']['name'] != 'modify_directive': continue
                    db.modify_directive(**json.loads(tool['function']['arguments']))
                except (ValueError,TypeError,KeyError,PermissionError): db.log('tool_error','Rejected invalid directive change')
            messages[0]['content']+='\nCurrent directives: '+json.dumps(db.directives())
        queue=asyncio.Queue(); worker=asyncio.create_task(speaker.run(queue,send)); response=''; sentence=''
        try:
            async for token in router.stream(messages):
                response+=token; sentence+=token
                await send({'type':'token','text':token})
                if re.search(r'[.!?](?:\s|$)',sentence): await queue.put(sentence); sentence=''
            if sentence: await queue.put(sentence)
        finally:
            await queue.put(None); await worker
        return {'response':response}
    async def write(s):
        db.log('chat',{'input':s['text'],'output':s['response'],'kind':s.get('kind','text'),'timestamp':s['timestamp']})
        with db.connection() as c: count=c.execute("SELECT count(*) FROM logs WHERE kind='chat'").fetchone()[0]
        if count>=10: await memory.consolidate()
        return {}
    graph=StateGraph(CognitiveState)
    nodes=[('input_normalizer',normalize),('memory_retriever',retrieve),('conflict_evaluator',evaluate),('state_engine',state),('response_generator',generate),('memory_writer',write)]
    previous=START
    for name,fn in nodes: graph.add_node(name,fn); graph.add_edge(previous,name); previous=name
    graph.add_edge(previous,END)
    return graph.compile()

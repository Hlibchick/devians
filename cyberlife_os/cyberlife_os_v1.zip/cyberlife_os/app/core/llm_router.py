import json
import httpx
class Router:
    def __init__(self, settings):
        self.s = settings
        self.provider = 'api'
        self.status = 'unprobed'
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(60, connect=2))
    async def close(self): await self.client.aclose()
    def targets(self):
        s=self.s
        if self.provider == 'api' and s.primary_api_base_url:
            yield s.primary_api_base_url.rstrip('/')+'/chat/completions', {'Authorization':'Bearer '+s.primary_api_key}, s.primary_model, 'api'
        yield s.ollama_base_url.rstrip('/')+'/v1/chat/completions', {}, s.local_fallback_model, 'local'
    async def complete(self, messages, json_mode=False, tools=None, vision=False):
        for url, headers, model, label in self.targets():
            if vision and label == 'local': continue
            try:
                body=dict(model=(self.s.vision_model if vision else model), messages=messages, stream=False, max_tokens=512)
                if json_mode: body['response_format']={'type':'json_object'}
                if tools: body['tools']=tools
                r=await self.client.post(url, headers=headers, json=body); r.raise_for_status()
                message=r.json()['choices'][0]['message']
                self.status=label
                return message
            except (httpx.HTTPError, KeyError, ValueError, IndexError): continue
        self.status='mock'
        return {'content': None}
    async def stream(self, messages):
        for url, headers, model, label in self.targets():
            emitted=False
            try:
                async with self.client.stream('POST',url,headers=headers,json=dict(model=model,messages=messages,stream=True,max_tokens=512)) as r:
                    r.raise_for_status()
                    async for line in r.aiter_lines():
                        if not line.startswith('data:'): continue
                        data=line[5:].strip()
                        if data == '[DONE]': break
                        token=json.loads(data)['choices'][0].get('delta',{}).get('content')
                        if token:
                            emitted=True; self.status=label; yield token
                if emitted: return
            except (httpx.HTTPError, ValueError, KeyError, IndexError):
                if emitted:
                    yield '\n[Stream interrupted]'; return
        self.status='mock'
        yield '[MOCK] Models unavailable. Diagnostic mode: request recorded; no model-generated answer.'
    async def embed(self,text):
        try:
            r=await self.client.post(self.s.ollama_base_url.rstrip('/')+'/api/embeddings',json={'model':self.s.embedding_model,'prompt':text,'keep_alive':0})
            r.raise_for_status(); return r.json()['embedding']
        except (httpx.HTTPError,KeyError,ValueError): return None
